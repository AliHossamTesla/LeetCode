class Problem:
    name = ""
    rating = -1
    code = ""

def line():
    print("- "*16)
